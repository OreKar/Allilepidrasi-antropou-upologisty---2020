﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cinema_Complex
{
    public partial class Main1 : Form
    {
        public Main1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Hide();
            Tickets T = new Tickets();
            T.ShowDialog();
            Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Hide();
            Times T = new Times();
            T.ShowDialog();
            Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Hide();
            Movies M = new Movies();
            M.ShowDialog();
            Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Πατήστε παίζονται τώρα για να δείτε τις ταινίες που είναι διαθέσιμες, πατήστε μενού μπαρ για να δείτε τα προιόντα του μπαρ και τις τιμές τους και τέλος για κράτηση-αγορά εισιτηρίων πατήστε κράτηση-αγορά");

        }
    }
}
