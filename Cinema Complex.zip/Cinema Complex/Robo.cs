﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cinema_Complex
{
    public partial class Robo : Form
    {
        public Robo()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Clean C = new Clean();
            C.ShowDialog();
            Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Items I = new Items();
            I.ShowDialog();
            Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Για αναθεση της σκούπας για καθαρισμο πατήστε καθαρισμός και για να δείτε τα χαμένα αντικείμενα που βρήκε πατήστε χαμένα αντικείμενα");
        }
    }
}
