﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cinema_Complex
{
    public partial class Spaces : Form
    {
        public Spaces()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (label6.BackColor == Color.Lime)
            {

                label6.BackColor = Color.Red;
            }
            else label6.BackColor = Color.Lime;
        }

        private void button2_Click(object sender, EventArgs e)
        {

            if (label1.BackColor == Color.Lime)
            {

                label1.BackColor = Color.Red;
            }
            else label1.BackColor = Color.Lime;
        }

        private void button4_Click(object sender, EventArgs e)
        {

            if (label3.BackColor == Color.Lime)
            {

                label3.BackColor = Color.Red;
            }
            else label3.BackColor = Color.Lime;
        }

        private void button5_Click(object sender, EventArgs e)
        {

            if (label4.BackColor == Color.Lime)
            {

                label4.BackColor = Color.Red;
            }
            else label4.BackColor = Color.Lime;
        }

        private void button8_Click(object sender, EventArgs e)
        {

            if (label8.BackColor == Color.Lime)
            {

                label8.BackColor = Color.Red;
            }
            else label8.BackColor = Color.Lime;
        }

        private void button7_Click(object sender, EventArgs e)
        {

            if (label7.BackColor == Color.Lime)
            {

                label7.BackColor = Color.Red;
            }
            else label7.BackColor = Color.Lime;
        }

        private void button6_Click(object sender, EventArgs e)
        {

            if (label5.BackColor == Color.Lime)
            {

                label5.BackColor = Color.Red;
            }
            else label5.BackColor = Color.Lime;
        }

        private void button12_Click(object sender, EventArgs e)
        {

            if (label12.BackColor == Color.Lime)
            {

                label12.BackColor = Color.Red;
            }
            else label12.BackColor = Color.Lime;
        }

        private void button11_Click(object sender, EventArgs e)
        {

            if (label11.BackColor == Color.Lime)
            {

                label11.BackColor = Color.Red;
            }
            else label11.BackColor = Color.Lime;
        }

        private void button10_Click(object sender, EventArgs e)
        {

            if (label10.BackColor == Color.Lime)
            {

                label10.BackColor = Color.Red;
            }
            else label10.BackColor = Color.Lime;
        }

        private void button9_Click(object sender, EventArgs e)
        {

            if (label9.BackColor == Color.Lime)
            {

                label9.BackColor = Color.Red;
            }
            else label9.BackColor = Color.Lime;
        }

        private void button15_Click(object sender, EventArgs e)
        {
            if (label15.BackColor == Color.Lime)
            {

                label15.BackColor = Color.Red;
            }
            else label15.BackColor = Color.Lime;
        }

        private void button14_Click(object sender, EventArgs e)
        {
            if (label14.BackColor == Color.Lime)
            {

                label14.BackColor = Color.Red;
            }
            else label14.BackColor = Color.Lime;
        }

        private void button13_Click(object sender, EventArgs e)
        {
            if (label13.BackColor == Color.Lime)
            {

                label13.BackColor = Color.Red;
            }
            else label13.BackColor = Color.Lime;
        }

        private void button16_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Πατήστε το κουμπί ON/OFF στον αντίστοιχο χώρο που θέλετε για να κλείσετε ή να ανάψετε τα φώτα");
        }
    }
}
