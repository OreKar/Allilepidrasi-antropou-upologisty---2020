﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cinema_Complex
{
    public partial class Items : Form
    {
        public Items()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            label15.Visible = false;
            button3.Visible = false;
            MessageBox.Show("Ο πελάτης ενημερώθηκε με email");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            label1.Visible = false;
            button2.Visible = false;
            MessageBox.Show("Ο πελάτης ενημερώθηκε με email");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            label3.Visible = false;
            button4.Visible = false;
            MessageBox.Show("Ο πελάτης ενημερώθηκε με email");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            label4.Visible = false;
            button5.Visible = false;
            MessageBox.Show("Ο πελάτης ενημερώθηκε με email");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            label5.Visible = false;
            button6.Visible = false;
            MessageBox.Show("Ο πελάτης ενημερώθηκε με email");
        }

        private void button7_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Πατήστε ενημέρωση πελάτη για να σταλθεί email στον πελάτη που καθόταν στην θέση για να ενημερωθεί πως βρέθηκε χαμένα αντικείμενο στην θέση που καθόταν και εάν του λείπει κάτι κι αν ναι τι ακριβώς ");
        }
    }
}
