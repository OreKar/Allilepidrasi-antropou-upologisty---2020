﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cinema_Complex
{
    public partial class Complete : Form
    {
        public Complete()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Main1 M = new Main1();
            M.ShowDialog();
            Show();
            this.Close();
            
        }

        private void Complete_Load(object sender, EventArgs e)
        {
            MessageBox.Show("Την προηγούμενη φορά που έγινε κράτηση σε αυτό το όνομα η θέση είχε λερωθεί πολύ. Παρακαλούμε την επόμενη φορά να είστε προσεκτικότερος");

        }
    }
}
