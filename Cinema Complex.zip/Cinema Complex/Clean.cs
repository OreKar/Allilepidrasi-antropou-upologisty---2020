﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cinema_Complex
{
    public partial class Clean : Form
    {
        public Clean()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Η σκούπα ρομπότ πάει στην αίθουσα να καθαρίσει");

        }

        private void button4_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Για να αναθέσετε την σκούπα να καθαρίσει επιλέξτε την αίθουσα ή ακόμα και κάποια συγκεκριμένη θέση στην αίθουσα αυτή και πατήστε καθαρισμός");
        }
    }
}
