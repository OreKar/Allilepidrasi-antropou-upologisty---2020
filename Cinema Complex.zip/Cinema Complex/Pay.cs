﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cinema_Complex
{
    public partial class Pay : Form
    {
        public Pay()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Pay_Load(object sender, EventArgs e)
        {
            label8.Text = Tickets.la;
            progressBar1.Visible = false;
        }

        private void progressBar1_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.timer1.Start();
            progressBar1.Visible = true;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            this.progressBar1.Increment(1);
            if (progressBar1.Value == progressBar1.Maximum)
            {
                timer1.Stop();
                this.Hide();
                Complete CP = new Complete();
                CP.ShowDialog();
                Show();
                this.Close();
               
                
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Γράψτε τα στοιχία της κάρτας σας για να κάνετε την πληρωμή");
        }
    }
}
