﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cinema_Complex
{
    public partial class Machines : Form
    {
        public Machines()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Το κάλεμσα του ασανσέρ 1 πέτχυε");
        }

        private void button7_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Το κάλεμσα του ασανσέρ 2 πέτχυε");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Το κάλεμσα του ασανσέρ 3 πέτχυε");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (label6.BackColor == Color.Lime)
            {

                label6.BackColor = Color.Red;
            }
            else label6.BackColor = Color.Lime;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (label1.BackColor == Color.Lime)
            {

                label1.BackColor = Color.Red;
            }
            else label1.BackColor = Color.Lime;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (label3.BackColor == Color.Lime)
            {

                label3.BackColor = Color.Red;
            }
            else label3.BackColor = Color.Lime;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (label4.BackColor == Color.Lime)
            {

                label4.BackColor = Color.Red;
            }
            else label4.BackColor = Color.Lime;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (label9.BackColor == Color.Lime)
            {

                label9.BackColor = Color.Red;
            }
            else label9.BackColor = Color.Lime;
        }

        private void button10_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Πατήστε το κουμπί ON/OFF για να ξεκινήσετε ή να κλείσετε κάποιο μηχάνημα και συγκεκριμένα για τα ασανσέρ επιλέγετε τον όροφο που θέλετε να το στείλετε");
        }
    }
}
