﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cinema_Complex
{
    public partial class Tickets : Form
    {


        public Tickets()
        {
            InitializeComponent();

            

        }


        List<string> colors = new List<string>(new string[] { "White","Red"});
        Random r = new Random();


        public static int a = 0;
        public static int b = 0;
        public static int c = 0;
        public static int d = 0;
        public static int f = 0;
        public static int g = 0;
        public static int h = 0;
        public static int sum = 0;
        public static int sc1 = 0;
        public static int sc2 = 0;
        public static int sc3 = 0;
        public static int sc4 = 0;
        public static int sc5 = 0;
        public static int sc6 = 0;
        public static int sc7 = 0;
        public static int sc8 = 0;
        public static int sb1 = 0;
        public static int sb2 = 0;
        public static int sb3 = 0;
        public static int sb4 = 0;
        public static int sb5 = 0;
        public static int sb6 = 0;
        public static int sb7 = 0;
        public static int sb8 = 0;
        public static int sa1 = 0;
        public static int sa2 = 0;
        public static int sa3 = 0;
        public static int sa4 = 0;
        public static int sa5 = 0;
        public static int sa6 = 0;
        public static string la = "";

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }


        Random random = new Random();
       
        private void Tickets_Load(object sender, EventArgs e)
        {
            groupBox4.Visible = false;


        }


      


        private void button5_Click(object sender, EventArgs e)
        {
            if (a > 0)
            {
                a--;
                label14.Text = a.ToString();
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            a++;
            label14.Text = a.ToString();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (b > 0)
            {
                b--;
                label15.Text = b.ToString();
            }
        }

        private void button11_Click(object sender, EventArgs e)
        {
            b++;
            label15.Text = b.ToString();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (c > 0)
            {
                c--;
                label16.Text = c.ToString();
            }
        }

        private void button12_Click(object sender, EventArgs e)
        {
            c++;
            label16.Text = c.ToString();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (d > 0)
            {
                d--;
                label17.Text = d.ToString();
            }
        }

        private void button13_Click(object sender, EventArgs e)
        {
            d++;
            label17.Text = d.ToString();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (f > 0)
            {
                f--;
                label18.Text = f.ToString();
            }
        }

        private void button14_Click(object sender, EventArgs e)
        {
            f++;
            label18.Text = f.ToString();
        }

        private void button16_Click(object sender, EventArgs e)
        {

            sum = (a * 4) + (b * 2) + (c * 2) + (d * 4)+(g*2)+(h*3) + f + sc1 + sc2 + sc3 + sc4 + sc5 + sc6 + sc7 + sc8+sb1+sb2+sb3+sb4+sb5+sb6+sb7+sb8+sa1+sa2+sa3+sa4+sa5+sa6;


            label8.Text = sum.ToString();
            la = label8.Text;
            sum = 0;
        }

        private void button15_Click(object sender, EventArgs e)
        {
            Hide();
            Times T = new Times();
            T.ShowDialog();
            Show();
        }

        /////////////////////////////////////////////////////////////////////////////////////////ΘΕΣΕΙΣ C
        private void C1_Click(object sender, EventArgs e)
        {
            if (C1.BackColor == Color.White)
            {
                sc1 = sc1 + 7;
                C1.BackColor = Color.Yellow;
            }
            else if (C1.BackColor == Color.Yellow)
            {
                sc1 = sc1 - 7;
                C1.BackColor = Color.White;
            }

        }

        private void C2_Click(object sender, EventArgs e)
        {
            if (C2.BackColor == Color.White)
            {
                sc2 = sc2 + 7;
                C2.BackColor = Color.Yellow;
            }
            else if (C2.BackColor == Color.Yellow)
            {
                sc2 = sc2 - 7;
                C2.BackColor = Color.White;
            }
        }

        private void C3_Click(object sender, EventArgs e)
        {

            if (C3.BackColor == Color.White)
            {
                sc3 = sc3 + 7;
                C3.BackColor = Color.Yellow;
            }
            else if (C3.BackColor == Color.Yellow)
            {
                sc3 = sc3 - 7;
                C3.BackColor = Color.White;
            }
        }

        private void C4_Click(object sender, EventArgs e)
        {
            if (C4.BackColor == Color.White)
            {
                sc4 = sc4 + 7;
                C4.BackColor = Color.Yellow;
            }
            else if (C4.BackColor == Color.Yellow)
            {
                sc4 = sc4 - 7;
                C4.BackColor = Color.White;
            }
        }

        private void C5_Click(object sender, EventArgs e)
        {
            if (C5.BackColor == Color.White)
            {
                sc5 = sc5 + 7;
                C5.BackColor = Color.Yellow;
            }
            else if (C5.BackColor == Color.Yellow)
            {
                sc5 = sc5 - 7;
                C5.BackColor = Color.White;
            }

        }

        private void C6_Click(object sender, EventArgs e)
        {
            if (C6.BackColor == Color.White)
            {
                sc6 = sc6 + 7;
                C6.BackColor = Color.Yellow;
            }
            else if (C6.BackColor == Color.Yellow)
            {
                sc6 = sc6 - 7;
                C6.BackColor = Color.White;
            }
        }

        private void C7_Click(object sender, EventArgs e)
        {
            if (C7.BackColor == Color.White)
            {
                sc7 = sc7 + 7;
                C7.BackColor = Color.Yellow;
            }
            else if (C7.BackColor == Color.Yellow)
            {
                sc7 = sc7 - 7;
                C7.BackColor = Color.White;
            }
        }

        private void C8_Click(object sender, EventArgs e)
        {
            if (C8.BackColor == Color.White)
            {
                sc8 = sc8 + 7;
                C8.BackColor = Color.Yellow;
            }
            else if (C8.BackColor == Color.Yellow)
            {
                sc8 = sc8 - 7;
                C8.BackColor = Color.White;
            }

        }


      

        private void comboBox2_SelectionChangeCommitted(object sender, EventArgs e)
        {

            groupBox4.Visible = true;
         
            if (comboBox2.SelectedItem == "1")
            {
                C1.BackColor = Color.White;
                C2.BackColor = Color.Red;
                C3.BackColor = Color.Red;
                C4.BackColor = Color.White;
                C5.BackColor = Color.White;
                C6.BackColor = Color.White;
                C7.BackColor = Color.Red;
                C8.BackColor = Color.Red;
                B1.BackColor = Color.White;
                B2.BackColor = Color.White;
                B3.BackColor = Color.Red;
                B4.BackColor = Color.White;
                B5.BackColor = Color.White;
                B6.BackColor = Color.White;
                B7.BackColor = Color.White;
                B8.BackColor = Color.White;
                A1.BackColor = Color.White;
                A2.BackColor = Color.White;
                A3.BackColor = Color.White;
                A4.BackColor = Color.Red;
                A5.BackColor = Color.White;
                A6.BackColor = Color.Red;


            }
            else if (comboBox2.SelectedItem == "2")
            {
                C2.BackColor = Color.Red;
                C3.BackColor = Color.Red;
                B2.BackColor = Color.Red;
                B8.BackColor = Color.Red;

            }

            else if (comboBox2.SelectedItem == "3")
            {
                C1.BackColor = Color.White;
                C2.BackColor = Color.Red;
                C3.BackColor = Color.Red;
                C4.BackColor = Color.White;
                C5.BackColor = Color.White;
                C6.BackColor = Color.White;
                C7.BackColor = Color.Red;
                C8.BackColor = Color.Red;
                B1.BackColor = Color.Red;
                B2.BackColor = Color.White;
                B3.BackColor = Color.Red;
                B4.BackColor = Color.White;
                B5.BackColor = Color.Red;
                B6.BackColor = Color.White;
                B7.BackColor = Color.Red;
                B8.BackColor = Color.White;
                A1.BackColor = Color.Red;
                A2.BackColor = Color.White;
                A3.BackColor = Color.Red;
                A4.BackColor = Color.Red;
                A5.BackColor = Color.White;
                A6.BackColor = Color.Red;
            }

            else if (comboBox2.SelectedItem == "4")
            {
                C1.BackColor = Color.Red;

            }

        }
        /////////////////////////////////////////////////////////////////////////////////////////ΘΕΣΕΙΣ B
        private void B1_Click_1(object sender, EventArgs e)
        {
            if (B1.BackColor == Color.White)
            {
                sb1 = sb1 + 12;
                B1.BackColor = Color.Yellow;
            }
            else if (B1.BackColor == Color.Yellow)
            {
                sb1 = sb1 - 12;
                B1.BackColor = Color.White;
            }
        }

        private void B2_Click_1(object sender, EventArgs e)
        {
            if (B2.BackColor == Color.White)
            {
                sb2 = sb2 + 12;
                B2.BackColor = Color.Yellow;
            }
            else if (B2.BackColor == Color.Yellow)
            {
                sb2 = sb2 - 12;
                B2.BackColor = Color.White;
            }
        }

        private void B3_Click_1(object sender, EventArgs e)
        {
            if (B3.BackColor == Color.White)
            {
                sb3 = sb3 + 12;
                B3.BackColor = Color.Yellow;
            }
            else if (B3.BackColor == Color.Yellow)
            {
                sb3 = sb3 - 12;
                B3.BackColor = Color.White;
            }
        }

        private void B4_Click_1(object sender, EventArgs e)
        {
            if (B4.BackColor == Color.White)
            {
                sb4 = sb4 + 12;
                B4.BackColor = Color.Yellow;
            }
            else if (B4.BackColor == Color.Yellow)
            {
                sb4 = sb4 - 12;
                B4.BackColor = Color.White;
            }
        }

        private void B5_Click_1(object sender, EventArgs e)
        {
            if (B5.BackColor == Color.White)
            {
                sb5 = sb5 + 12;
                B5.BackColor = Color.Yellow;
            }
            else if (B5.BackColor == Color.Yellow)
            {
                sb5 = sb5 - 12;
                B5.BackColor = Color.White;
            }
        }

        private void B6_Click_1(object sender, EventArgs e)
        {
            if (B6.BackColor == Color.White)
            {
                sb6 = sb6 + 12;
                B6.BackColor = Color.Yellow;
            }
            else if (B6.BackColor == Color.Yellow)
            {
                sb6 = sb6 - 12;
                B6.BackColor = Color.White;
            }
        }

        private void B7_Click_1(object sender, EventArgs e)
        {
            if (B7.BackColor == Color.White)
            {
                sb7 = sb7 + 12;
                B7.BackColor = Color.Yellow;
            }
            else if (B7.BackColor == Color.Yellow)
            {
                sb7 = sb7 - 12;
                B7.BackColor = Color.White;
            }
        }

        private void B8_Click_1(object sender, EventArgs e)
        {
            if (B8.BackColor == Color.White)
            {
                sb8 = sb8 + 12;
                B8.BackColor = Color.Yellow;
            }
            else if (B8.BackColor == Color.Yellow)
            {
                sb8 = sb8 - 12;
                B8.BackColor = Color.White;
            }
        }

        /////////////////////////////////////////////////////////////////////////////////////////ΘΕΣΕΙΣ A
        private void A1_Click(object sender, EventArgs e)
        {
            if (A1.BackColor == Color.White)
            {
                sa1 = sa1 + 10;
                A1.BackColor = Color.Yellow;
            }
            else if (A1.BackColor == Color.Yellow)
            {
                sa1 = sa1 - 10;
                A1.BackColor = Color.White;
            }
        }

        private void A2_Click(object sender, EventArgs e)
        {
            if (A2.BackColor == Color.White)
            {
                sa2 = sa2 + 10;
                A2.BackColor = Color.Yellow;
            }
            else if (A2.BackColor == Color.Yellow)
            {
                sa2 = sa2 - 10;
                A2.BackColor = Color.White;
            }
        }

        private void A3_Click(object sender, EventArgs e)
        {
            if (A3.BackColor == Color.White)
            {
                sa3 = sa3 + 10;
                A3.BackColor = Color.Yellow;
            }
            else if (A3.BackColor == Color.Yellow)
            {
                sa3 = sa3 - 10;
                A3.BackColor = Color.White;
            }
        }

        private void A4_Click(object sender, EventArgs e)
        {
            if (A4.BackColor == Color.White)
            {
                sa4 = sa4 + 10;
                A4.BackColor = Color.Yellow;
            }
            else if (A4.BackColor == Color.Yellow)
            {
                sa4 = sa4 - 10;
                A4.BackColor = Color.White;
            }
        }

        private void A5_Click(object sender, EventArgs e)
        {
            if (A5.BackColor == Color.White)
            {
                sa5 = sa5 + 10;
                A5.BackColor = Color.Yellow;
            }
            else if (A5.BackColor == Color.Yellow)
            {
                sa5 = sa5 - 10;
                A5.BackColor = Color.White;
            }
        }

        private void A6_Click(object sender, EventArgs e)
        {
            if (A6.BackColor == Color.White)
            {
                sa6 = sa6 + 10;
                A6.BackColor = Color.Yellow;
            }
            else if (A6.BackColor == Color.Yellow)
            {
                sa6 = sa6 - 10;
                A6.BackColor = Color.White;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Pay P = new Pay();
            P.ShowDialog();
            Show();
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (g > 0)
            {
                g--;
                label34.Text = g.ToString();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            g++;
            label34.Text = g.ToString();
        }

        private void button18_Click(object sender, EventArgs e)
        {
            if (h > 0)
            {
                h--;
                label35.Text = h.ToString();
            }
        }

        private void button17_Click(object sender, EventArgs e)
        {
            h++;
            label35.Text = h.ToString();
        }

        private void button19_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Επιλέξτε ταινία, αίθουσα, ημερομηνία, ώρα και θέσεις καθώς και αν θέλετε κάτι από το μπαρ. Στη συνέχεια πατήστε υπολογισμός για να δείτε το συνολικό κόστος και πατήστε πληρωμή με κάρτα");
        }
    }
}
