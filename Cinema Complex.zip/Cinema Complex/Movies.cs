﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cinema_Complex
{
    public partial class Movies : Form
    {
        public Movies()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Joker J = new Joker();
            J.ShowDialog();
            Show();
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Ave A = new Ave();
            A.ShowDialog();
            Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Par P = new Par();
            P.ShowDialog();
            Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            Xilia X = new Xilia();
            X.ShowDialog();
            Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Hide();
            HANS H = new HANS();
            H.ShowDialog();
            Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            MessageBox.Show("πατήστε την ταινία που σας ενδιαφέρει για να μάθετε πληροφορίες γιαυτήν");
        }
    }
}
