﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cinema_Complex
{
    public partial class Orders : Form
    {
        public Orders()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            label6.Visible = false;
            button2.Visible = false;
            button3.Visible = false;
            MessageBox.Show("Η παραγγελία απορρίφθηκε");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            label6.Visible = false;
            button2.Visible = false;
            button3.Visible = false;
            MessageBox.Show("Η παραγγελία εγκρίθηκε");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            label1.Visible = false;
            button4.Visible = false;
            button5.Visible = false;
            MessageBox.Show("Η παραγγελία απορρίφθηκε");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            label1.Visible = false;
            button4.Visible = false;
            button5.Visible = false;
            MessageBox.Show("Η παραγγελία εγκρίθηκε");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            label3.Visible = false;
            button6.Visible = false;
            button7.Visible = false;
            MessageBox.Show("Η παραγγελία απορρίφθηκε");
        }

        private void button7_Click(object sender, EventArgs e)
        {
            label3.Visible = false;
            button6.Visible = false;
            button7.Visible = false;
            MessageBox.Show("Η παραγγελία εγκρίθηκε");
        }

        private void button8_Click(object sender, EventArgs e)
        {

            label4.Visible = false;
            button8.Visible = false;
            button9.Visible = false;
            MessageBox.Show("Η παραγγελία απορρίφθηκε");
        }

        private void button9_Click(object sender, EventArgs e)
        {
            label4.Visible = false;
            button8.Visible = false;
            button9.Visible = false;
            MessageBox.Show("Η παραγγελία εγκρίθηκε");
        }

        private void button10_Click(object sender, EventArgs e)
        {
            label5.Visible = false;
            button10.Visible = false;
            button11.Visible = false;
            MessageBox.Show("Η παραγγελία απορρίφθηκε");
        }

        private void button11_Click(object sender, EventArgs e)
        {
            label5.Visible = false;
            button10.Visible = false;
            button11.Visible = false;
            MessageBox.Show("Η παραγγελία εγκρίθηκε");
        }

        private void button12_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Πατήστε απόρριψη ή έγκριση ανάλογα τι θέλετε να κάνετε για κάθε παραγγελία που είναι διαθέσιμη να εκτελεσθεί");
        }
    }
}
